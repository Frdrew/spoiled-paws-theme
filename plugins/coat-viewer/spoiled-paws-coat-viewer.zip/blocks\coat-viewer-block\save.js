export default function save() {
    return (
        <div class="spcv-viewer-root">
            Loading viewer…
        </div>
    );
}
