// Small helpers for loading
window.spcvLoad = function(sel) {
    return document.querySelector(sel);
};
