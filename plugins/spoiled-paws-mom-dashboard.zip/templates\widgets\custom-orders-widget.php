<p>Stats widget placeholder.</p>
