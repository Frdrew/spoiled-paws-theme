<div class="spmd-container">
    <h1>Spoiled Paws Dashboard</h1>

    <div id="spmd-stats" class="spmd-stats">
        Loading stats...
    </div>

    <h2>Recent Orders</h2>
    <div id="spmd-orders" class="spmd-orders">
        Loading orders...
    </div>
</div>
