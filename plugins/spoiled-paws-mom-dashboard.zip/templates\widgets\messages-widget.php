<p>Messages widget placeholder.</p>
