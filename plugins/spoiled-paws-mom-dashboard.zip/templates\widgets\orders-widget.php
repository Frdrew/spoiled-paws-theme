<p>Orders widget placeholder.</p>
