# ==============================================
# BUILD SCRIPT: Mom Dashboard Plugin
# ==============================================

Write-Host "Packaging plugin: mom-dashboard..." -ForegroundColor Cyan

$plugin   = "mom-dashboard"
$source   = (Get-Location).Path
$zipName  = "spoiled-paws-mom-dashboard.zip"
$zipPath  = Join-Path $source $zipName

# ---------------------------------------------
# Force delete any existing ZIP
# ---------------------------------------------
if (Test-Path $zipPath) {
    try {
        Remove-Item $zipPath -Force -ErrorAction Stop
    } catch {
        $temp = "$zipPath.locked_$(Get-Date -Format 'yyyyMMddHHmmss')"
        Rename-Item $zipPath $temp -Force
    }
}

# ---------------------------------------------
# Create ZIP
# ---------------------------------------------
try {
    Write-Host "Creating zip file..." -ForegroundColor Yellow
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::CreateFromDirectory($source, $zipPath)
} catch {
    Write-Host "ZIP BUILD FAILED:" -ForegroundColor Red
    Write-Host $_.Exception.Message
    exit
}

Write-Host "Plugin packaged: $zipName" -ForegroundColor Green
